import { useEffect, useState } from 'react';
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import * as anchor from "@project-serum/anchor";
import {
  AccountLayout,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  NATIVE_MINT,
  Token
} from "@solana/spl-token";
import { 
  programs 
} from '@metaplex/js'
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  ConfirmOptions,
  SystemProgram,
  NonceAccount
} from "@solana/web3.js";
import axios from "axios"
import { publicKey } from '@project-serum/anchor/dist/cjs/utils';
const idl = require('./solana_anchor.json')


const usdt_mint = new PublicKey("4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU")                 /// usdc mint address on devnet
const monkpayProgramId = new PublicKey("CrQ7WJWBYrgvmuM45HPC1i4BhKrfaXqQ4Z9jQAJ9Pg71")          /// program address on devnet

const buySellProgramId = new PublicKey("Fg6AH8MnHDZ6bn6tM7etqApeZyM5vqQKTTHwjpiYzqJq");
const PREFIX = "offermaker";
const { metadata: { Metadata } } = programs
const TOKEN_METADATA_PROGRAM_ID = new anchor.web3.PublicKey(
  "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
)
const confirmOption : ConfirmOptions = {
    commitment : 'finalized',
    preflightCommitment : 'finalized',
    skipPreflight : false,
}

const CANDY_MACHINE_PROGRAM = new anchor.web3.PublicKey("cndy3Z4yapfJBmL3ShUp5exZKqR3z33thTzeNMm2gRZ");

const MAX_NAME_LENGTH = 32;
const MAX_URI_LENGTH = 200;
const MAX_SYMBOL_LENGTH = 10;
const MAX_CREATOR_LEN = 32 + 1 + 1;
const BIDDATA_SIZE = 8 + 32 + 32 + 32 + 8 + 1 + 8 + 8;


const MONKPAY_SIZE = 8 + 32 + 32 + 32 + 32 + 8 + 1;
const ACCOUNT_DATA = 8 + 32 + 32 + 8 + 8;

const createAssociatedTokenAccountInstruction = (
  associatedTokenAddress: anchor.web3.PublicKey,
  payer: anchor.web3.PublicKey,
  walletAddress: anchor.web3.PublicKey,
  splTokenMintAddress: anchor.web3.PublicKey
    ) => {
  const keys = [
    { pubkey: payer, isSigner: true, isWritable: true },
    { pubkey: associatedTokenAddress, isSigner: false, isWritable: true },
    { pubkey: walletAddress, isSigner: false, isWritable: false },
    { pubkey: splTokenMintAddress, isSigner: false, isWritable: false },
    {
      pubkey: anchor.web3.SystemProgram.programId,
      isSigner: false,
      isWritable: false,
    },
    { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    {
      pubkey: anchor.web3.SYSVAR_RENT_PUBKEY,
      isSigner: false,
      isWritable: false,
    },
  ];
  return new anchor.web3.TransactionInstruction({
    keys,
    programId: ASSOCIATED_TOKEN_PROGRAM_ID,
    data: Buffer.from([]),
  });
}

const getMetadata = async (
  mint: anchor.web3.PublicKey
    ): Promise<anchor.web3.PublicKey> => {
  return (
    await anchor.web3.PublicKey.findProgramAddress(
      [
        Buffer.from("metadata"),
        TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
      ],
      TOKEN_METADATA_PROGRAM_ID
    )
  )[0];
};

const getTokenWallet = async (
  wallet: anchor.web3.PublicKey,
  mint: anchor.web3.PublicKey
    ) => {
  return (
    await anchor.web3.PublicKey.findProgramAddress(
      [wallet.toBuffer(), TOKEN_PROGRAM_ID.toBuffer(), mint.toBuffer()],
      ASSOCIATED_TOKEN_PROGRAM_ID
    )
  )[0];
};

async function sendTransaction(
  wallet: any,
  conn: any,
  transaction : Transaction,
  signers : Keypair[],
) {
  try{
    transaction.feePayer = wallet.publicKey
    transaction.recentBlockhash = (await conn.getRecentBlockhash('max')).blockhash;
    transaction.setSigners(wallet.publicKey,...signers.map(s => s.publicKey));
    if(signers.length != 0)
      transaction.partialSign(...signers)
    const signedTransaction = await wallet.signTransaction(transaction);
    let hash = await conn.sendRawTransaction(await signedTransaction.serialize());
    await conn.confirmTransaction(hash);
  } catch(err) {
    console.log(err)
  }
}


async function getSPLTokenBalance (conn:any, account: PublicKey){
  let tokenInfo = await conn.getTokenAccountBalance(account);
  console.log("tst", tokenInfo.value.amount)
  let balance = tokenInfo.value.amount / Math.pow(10, tokenInfo.value.decimals) ;
  console.log("token balance", balance);
  return balance;
}

// Admin action
async function initMonkpay(conn: any, wallet: any, amount: number){

  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,monkpayProgramId,provider)
  let monkpayData = Keypair.generate();
  let nonce_account = Keypair.generate();
  let [vault, bump] = await PublicKey.findProgramAddress([Buffer.from(PREFIX)], monkpayProgramId);
  let usdt_account = await getTokenWallet(vault, usdt_mint);
  let randomPubkey = Keypair.generate().publicKey;

  let signers: Keypair[] = []
  let transaction = new Transaction()

  signers.push(monkpayData);
  signers.push(nonce_account);
  
  transaction.add(
    createAssociatedTokenAccountInstruction(
      usdt_account,
      wallet.publicKey,
      vault,
      usdt_mint
    )
  );

  console.log({vault: vault.toBase58(), monkpayData:monkpayData.publicKey.toBase58(), nonceAccount: nonce_account.publicKey.toBase58()})
  transaction.add(
    program.instruction.initMonkpay(
      bump,
      new anchor.BN(amount * anchor.web3.LAMPORTS_PER_SOL),
      {
        accounts:{
          signer: wallet.publicKey,
          vault: vault,
          monkpayData: monkpayData.publicKey,
          nonceAccount: nonce_account.publicKey,
          systemProgram: anchor.web3.SystemProgram.programId, 
          rent: anchor.web3.SYSVAR_RENT_PUBKEY,
          recentBlockhash: anchor.web3.SYSVAR_RECENT_BLOCKHASHES_PUBKEY,
          usdtAccount: usdt_account,
          usdtMint: usdt_mint,
          rand: randomPubkey
        }
      }
    )
  )
  await sendTransaction(wallet, conn, transaction, signers)
  return monkpayData.publicKey;
}

async function initAccount(
  conn: any,
  wallet: any,
  monkpayData: PublicKey
){
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,monkpayProgramId,provider)

  let account_data = Keypair.generate();
  if(monkpayData == null) return

  let signers: Keypair[] = []
  let transaction = new Transaction()

  signers.push(account_data);
  console.log(wallet.publicKey.toBase58(), monkpayData, account_data.publicKey)
  transaction.add(
    program.instruction.createAccount(
      {
        accounts:{
          owner: wallet.publicKey,
          monkpayData: monkpayData,
          accountData: account_data.publicKey,
          systemProgram: anchor.web3.SystemProgram.programId, 
        }
      }
    )
  )
  await sendTransaction(wallet, conn, transaction, signers);
}


async function depositUSDT(
  conn: any,
  wallet: any,
  amount: number,
  monkpayData: PublicKey
){
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,monkpayProgramId,provider)
  let [vault, bump] = await PublicKey.findProgramAddress([Buffer.from(PREFIX)], monkpayProgramId);
  let accountData = await findAccountData(conn, wallet);

  if(monkpayData == null) return

  let source_account = await getTokenWallet(wallet.publicKey, usdt_mint);
  let destination_account = await getTokenWallet(vault, usdt_mint);

  // let signers: Keypair[] = []
  let transaction = new Transaction()

  console.log("vault account", destination_account.toBase58());
  transaction.add(
    program.instruction.depositUsdt(
      new anchor.BN(amount * 1000000),
      {
        accounts:{
          owner: wallet.publicKey,
          monkpayData: monkpayData,
          accountData: accountData?.address,
          sourceAccount: source_account,
          destinationAccount: destination_account,
          usdtMint: usdt_mint,
          tokenProgram: TOKEN_PROGRAM_ID,
        }
      }
    )
    )
  await sendTransaction(wallet, conn, transaction, []);

}

async function withdrawUSDT(
  conn: any,
  wallet: any,
  amount: number,
  monkpayData: PublicKey
){
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,monkpayProgramId,provider)
  let [vault, bump] = await PublicKey.findProgramAddress([Buffer.from(PREFIX)], monkpayProgramId);
  let accountData = await findAccountData(conn, wallet);
 
  if(monkpayData == null) return

  let destination_account = await getTokenWallet(wallet.publicKey, usdt_mint);
  let source_account = await getTokenWallet(vault, usdt_mint);
  console.log("vault account", source_account.toBase58());
  // let signers: Keypair[] = []
  let transaction = new Transaction()

  transaction.add(
    program.instruction.withdrawUsdt(
      new anchor.BN(amount * 1000000),
      {
        accounts:{
          owner: wallet.publicKey,
          monkpayData: monkpayData,
          accountData: accountData?.address,
          sourceAccount: source_account,
          destinationAccount: destination_account,
          usdtMint: usdt_mint,
          tokenProgram: TOKEN_PROGRAM_ID,
          vault: vault
        }
      }
    )
    )
  await sendTransaction(wallet, conn, transaction, []);

}

async function refundUSDT(
  conn: any,
  wallet: any,
  amount: number,
  monkpayData: PublicKey
){
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,monkpayProgramId,provider)
  let [vault, bump] = await PublicKey.findProgramAddress([Buffer.from(PREFIX)], monkpayProgramId);
 
  if(monkpayData == null) return

  let destination_account = await getTokenWallet(wallet.publicKey, usdt_mint);
  let source_account = await getTokenWallet(vault, usdt_mint);
  let transaction = new Transaction()

  transaction.add(
    program.instruction.refundUsdt(
      new anchor.BN(amount * 1000000),
      {
        accounts:{
          owner: wallet.publicKey,
          monkpayData: monkpayData,
          sourceAccount: source_account,
          destinationAccount: destination_account,
          tokenProgram: TOKEN_PROGRAM_ID,
          vault: vault
        }
      }
    )
    )
  await sendTransaction(wallet, conn, transaction, []);
}

async function transferUSDT(
  conn: any,
  wallet: any,
  _amount: number,
  _destination: PublicKey
){
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,monkpayProgramId,provider)
  let sourceAccountData = await findAccountData(conn, wallet);
  if(sourceAccountData == null) return
  let destinationAccountData;
  let resp = await conn.getProgramAccounts(monkpayProgramId, {
    dataSlice: {length: 0, offset: 0},
    filters: [
      {dataSize: ACCOUNT_DATA},
      {memcmp: {offset: 8, bytes: _destination.toBase58()}},
    ]
  })
  for(let dataAccount of resp){
      destinationAccountData = dataAccount.pubkey;
  }



  let transaction = new Transaction()
  transaction.add(
    program.instruction.transferUsdt(
      new anchor.BN(_amount * 1000000),
      {
        accounts:{
          owner: wallet.publicKey,
          sourceAccountData: sourceAccountData.address,
          destinationAccountData: destinationAccountData,
        }
      }
    )
    )
  await sendTransaction(wallet, conn, transaction, []);
}
async function deposit(
  conn: any,
  wallet: any,
  _amount: any,
  ){
  console.log("+ init vault")
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,buySellProgramId,provider)
  let biddingWallet = await findBiddingWallet(conn, wallet)
  let signers : Keypair[] = []
  let transaction = new Transaction()

  if (biddingWallet === null) {
    let biddingWalletData = Keypair.generate()
    let nonceAccount = Keypair.generate()
  
    signers.push(biddingWalletData)
    signers.push(nonceAccount)
    let [vault, bump] = await PublicKey.findProgramAddress( [ Buffer.from(PREFIX) ], buySellProgramId )
  
    transaction.add(
      program.instruction.initBiddingWallet(
        bump,
        new anchor.BN(_amount * anchor.web3.LAMPORTS_PER_SOL),
        {
          accounts:{
            signer : wallet.publicKey,
            vault : vault,
            biddingWalletData: biddingWalletData.publicKey,
            nonceAccount : nonceAccount.publicKey,
            systemProgram : anchor.web3.SystemProgram.programId,
            rent: anchor.web3.SYSVAR_RENT_PUBKEY,
            recentBlockhash: anchor.web3.SYSVAR_RECENT_BLOCKHASHES_PUBKEY,
          }
        }
      )
    )
  } else {
  
    transaction.add(
      anchor.web3.SystemProgram.transfer({
        fromPubkey: wallet.publicKey,
        toPubkey: biddingWallet.data.nonceAccount,
        lamports: _amount * anchor.web3.LAMPORTS_PER_SOL,
      })
    )
  }

  await sendTransaction(wallet, conn, transaction, signers)
}

async function findMonkpayData(conn: any, wallet: any){
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, monkpayProgramId, provider);
  let resp = await conn.getProgramAccounts(monkpayProgramId, {
    dataSlice: {length: 0, offset: 0},
    filters: [
      {dataSize: MONKPAY_SIZE},
    ]
  })

  console.log("wgat ", resp);
  for(let dataAccount of resp){
    try{
      let monkpayData = await program.account.iMonkpayData.fetch(dataAccount.pubkey)
      return{
        address: dataAccount.pubkey,
        data: monkpayData,
      }
    } catch(e) {
      console.log(e)
      continue
    }
  }

  return null
}

async function findAccountData(conn: any, wallet: any){
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, monkpayProgramId, provider);
  let resp = await conn.getProgramAccounts(monkpayProgramId, {
    dataSlice: {length: 0, offset: 0},
    filters: [
      {dataSize: ACCOUNT_DATA},
      {memcmp: {offset: 8, bytes: wallet!.publicKey.toBase58()}},
    ]
  })
  for(let dataAccount of resp){
    try{
      let accountData = await program.account.iAccountData.fetch(dataAccount.pubkey)
      return{
        address: dataAccount.pubkey,
        data: accountData,
      }
    } catch(e) {
      console.log(e)
      continue
    }
  }

  return null
}


async function findBiddingWallet(
  conn: any,
  wallet: any,
) {
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, buySellProgramId, provider)

  let resp = await conn.getProgramAccounts(buySellProgramId,{
    dataSlice: {length: 0, offset: 0},
    filters: [
      {
        dataSize: 72
      },
      {
        memcmp:
        {
          offset: 8,
          bytes: wallet!.publicKey.toBase58()
        }
      },
    ]
  })
  for(let dataAccount of resp){
    try{
      let biddingWalletData = await program.account.biddingWalletData.fetch(dataAccount.pubkey)
      console.log(biddingWalletData)
      return {
        address: dataAccount.pubkey,
        data: biddingWalletData,
      }
    } catch(e) {
      console.log(e)
      continue
    }
  }
  return null
}


async function withdraw(
  conn: any,
  wallet: any,
  _amount: any,
  ){
  console.log("+ withdraw")
  let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,buySellProgramId,provider)
  const biddingWallet = await findBiddingWallet(conn, wallet)
  if(biddingWallet == null) {
    return
  }

  let transaction = new Transaction()
  let [vault, bump] = await PublicKey.findProgramAddress( [ Buffer.from(PREFIX) ], buySellProgramId )
console.log(vault.toBase58())
  transaction.add(
    program.instruction.withdrawFromBiddingWallet(
      bump,
      new anchor.BN(_amount * anchor.web3.LAMPORTS_PER_SOL),
      {
        accounts:{
          signer : wallet.publicKey,
          vault : vault,
          biddingWalletData: biddingWallet.address,
          nonceAccount : biddingWallet.data.nonceAccount,
          systemProgram : anchor.web3.SystemProgram.programId,
          rent: anchor.web3.SYSVAR_RENT_PUBKEY,
          recentBlockhash: anchor.web3.SYSVAR_RECENT_BLOCKHASHES_PUBKEY,
        }
      }
    )
  )
  await sendTransaction(wallet, conn, transaction,[])
}


async function makeOffer(
  conn: any,
  wallet: any,
  _bid_amount: any,
  _nft_mint: PublicKey,
  _expire_time: any,
){
	console.log("+ make offer")
	let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, buySellProgramId, provider)
  const bidData = Keypair.generate()
  const biddingWallet = await findBiddingWallet(conn, wallet)
  if(biddingWallet == null) {
    return
  }
  let [vault, bump] = await PublicKey.findProgramAddress( [ Buffer.from(PREFIX) ], buySellProgramId )

  let transaction = new Transaction()
  let signers : Keypair[] = []
  signers.push(bidData)
  transaction.add(
    program.instruction.makeOffer(
      bump,
      new anchor.BN(_bid_amount * (10 ** 9) ),
      new anchor.BN(_expire_time),
      {
      accounts: {
        signer : wallet.publicKey,
        bidData : bidData.publicKey,
        vault : vault,
        biddingWalletData: biddingWallet.address,
        nftMint: _nft_mint,
        nonceAccount : biddingWallet.data.nonceAccount,
        systemProgram : anchor.web3.SystemProgram.programId,
        clock : anchor.web3.SYSVAR_CLOCK_PUBKEY
      }
    })
  )
  await sendTransaction(wallet, conn, transaction, signers)
}

async function amendOffer(
  conn: any,
  wallet: any,
  _bid_amount: any,
  _bid_data: PublicKey,
  _expire_time: any,
){
	console.log("+ amend offer")
	let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, buySellProgramId, provider)
  const biddingWallet = await findBiddingWallet(conn, wallet)
  if(biddingWallet == null) {
    return
  }
  let [vault, bump] = await PublicKey.findProgramAddress( [ Buffer.from(PREFIX) ], buySellProgramId )

  let transaction = new Transaction()
  transaction.add(
    program.instruction.amendOffer(
      bump,
      new anchor.BN(_bid_amount * (10 ** 9) ),
      new anchor.BN(_expire_time),
      {
      accounts: {
        owner : wallet.publicKey,
        vault : vault,
        bidData : _bid_data,
        clock : anchor.web3.SYSVAR_CLOCK_PUBKEY
      }
    })
  )
  await sendTransaction(wallet, conn, transaction, [])
}



async function amendOfferBatch(
  conn: any,
  wallet: any,
  datas: any
 ){
	console.log("+ amend offer")
	let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, buySellProgramId, provider)
  const biddingWallet = await findBiddingWallet(conn, wallet)
  if(biddingWallet == null) {
    return
  }
  let [vault, bump] = await PublicKey.findProgramAddress( [ Buffer.from(PREFIX) ], buySellProgramId )

  let transaction = new Transaction()
  for(var i = 0; i < datas.length; i ++) {
    transaction.add(
      program.instruction.amendOffer(
        bump,
        new anchor.BN(datas[i]._bid_amount * (10 ** 9) ),
        new anchor.BN(datas[i]._expire_time),
        {
        accounts: {
          owner : wallet.publicKey,
          vault : vault,
          bidData : datas[i]._bid_data,
          clock : anchor.web3.SYSVAR_CLOCK_PUBKEY
        }
      })
    )
  }
  
  await sendTransaction(wallet, conn, transaction, [])
}

async function cancelOffer(
  conn: any,
  wallet: any,
  bidData: any
	){
	console.log("+ Cancel Offer")
	let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, buySellProgramId, provider)

  let transaction = new Transaction()
  transaction.add(
    program.instruction.cancelOffer(
      {
      accounts: {
        owner : wallet.publicKey,
        bidData : bidData,
      }
    })
  )
  await sendTransaction(wallet, conn, transaction, [])
}

async function rejectOffer(
  conn: any,
  wallet: any,
  bidData: any
	){
	console.log("+ reject Offer")
	let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl, buySellProgramId, provider)

  let transaction = new Transaction()
  transaction.add(
    program.instruction.rejectOffer(
      {
      accounts: {
        owner : wallet.publicKey,
        bidData : bidData,
      }
    })
  )
  await sendTransaction(wallet, conn, transaction, [])
}

async function acceptOffer(
  conn: any,
  wallet: any,
  bidData: any,
  nftMint: any,
	){
	console.log("+ Accept Offer")
	let provider = new anchor.Provider(conn, wallet as any, confirmOption)
  let program = new anchor.Program(idl,buySellProgramId,provider)
  let transaction = new Transaction()
  let signers : Keypair[] = []
  const bid_data_info = await program.account.bidData.fetch(new PublicKey(bidData))
  console.log(bid_data_info.nonceAccount.toBase58())

  let [vault, bump] = await PublicKey.findProgramAddress( [ Buffer.from(PREFIX) ], buySellProgramId )

  const metadata = await getMetadata(nftMint)
  const sourceNftAccount = await getTokenWallet( wallet.publicKey, nftMint )
  const destNftAccount = await getTokenWallet( bid_data_info.bidder, nftMint )
  if((await conn.getAccountInfo(destNftAccount)) == null)
  	transaction.add(
      createAssociatedTokenAccountInstruction(
        destNftAccount,
        wallet.publicKey,
        bid_data_info.bidder,
        nftMint
      )
    )

  const accountInfo: any = await conn.getParsedAccountInfo(metadata);
  let metadataData : any = new Metadata(wallet.publicKey.toString(), accountInfo.value);
  let creators: any = []

  for(var i = 0; i < metadataData.data.data.creators.length; i ++) {
    console.log(metadataData.data.data.creators[i].address)    
    creators.push({
      pubkey: new PublicKey(metadataData.data.data.creators[i].address),
      isSigner: false,
      isWritable: true,
    })
  }
  transaction.add(
  	program.instruction.sell(
      bump,
      {
  		accounts: {
  			owner : wallet.publicKey,
  			vault : vault,
  			bidData : bidData,        
        salesTaxRecipient: new PublicKey("3iYf9hHQPciwgJ1TCjpRUp1A3QW4AfaK7J6vCmETRMuu"),
        nftMint: nftMint,
        metadata: metadata,
        sourceNftAccount : sourceNftAccount,
        destNftAccount: destNftAccount,
        tokenProgram : TOKEN_PROGRAM_ID,
        systemProgram : anchor.web3.SystemProgram.programId,
        nonceAccount: bid_data_info.nonceAccount,
        rent: anchor.web3.SYSVAR_RENT_PUBKEY,
        recentBlockhash: anchor.web3.SYSVAR_RECENT_BLOCKHASHES_PUBKEY,
  		},
      remainingAccounts: creators,
  	})
  )
  await sendTransaction(wallet, conn, transaction, signers)
}

async function getOfferReceived(
  conn: Connection,
  wallet: any,
) {
  console.log("+ get Offer Received")
  const allTokens: any = []
  const tokenAccounts = await conn.getParsedTokenAccountsByOwner(wallet.publicKey, { programId: TOKEN_PROGRAM_ID });
  const provider = new anchor.Provider(conn, wallet, anchor.Provider.defaultOptions());
  const program = new anchor.Program(idl, buySellProgramId, provider);
  for (let index = 0; index < tokenAccounts.value.length; index++) {
    try{
      const tokenAccount = tokenAccounts.value[index];
      const tokenAmount = tokenAccount.account.data.parsed.info.tokenAmount;
      if (tokenAmount.uiAmount === 1 && tokenAmount.decimals === 0) {
        let nftMint = new PublicKey(tokenAccount.account.data.parsed.info.mint)
        let resp = await conn.getProgramAccounts(buySellProgramId,{
          dataSlice: {length: 0, offset: 0},
          filters: [
            {
              dataSize: BIDDATA_SIZE
            },
            {
              memcmp:
              {
                offset:8,
                bytes: nftMint.toBase58()
              }
            },
          ]
        })
        for(let dataAccount of resp){
          try{
            let bidData = await program.account.bidData.fetch(dataAccount.pubkey)
            const nonceBalance = await conn.getBalance(bidData.nonceAccount)
            let status = ""
            if(bidData.status === 0) status = "CANCELED"
            else if (bidData.status ===2) status = "ACCEPTED"
            else if (bidData.status === 3) status = "REJECTED"
            else if(nonceBalance >= bidData.bidAmount) {
              if( new Date().getTime() < bidData.expireTime * 1000)
                status = "ACTIVE"
              else status = "REJECTED"
            }
            else status="INVALID"
            let [pda] = await anchor.web3.PublicKey.findProgramAddress([ Buffer.from("metadata"), TOKEN_METADATA_PROGRAM_ID.toBuffer(), nftMint.toBuffer(), ], TOKEN_METADATA_PROGRAM_ID);
            let accountInfo: any = await conn.getParsedAccountInfo(pda);
            let metadata : any = new Metadata(wallet.publicKey.toString(), accountInfo.value);
            let { data }: any = await axios.get(metadata.data.data.uri)
            const entireData = { ...data, id: Number(data.name.replace( /^\D+/g, '').split(' - ')[0]) }
            allTokens.push({address : new PublicKey(nftMint), ...entireData,
              bidder : bidData.bidder.toBase58(),
              bidAmount :bidData.bidAmount / (10 ** 9),
              status : status,
              bidData: dataAccount.pubkey,
              nftMint: bidData.nftMint,
              bidTime: new Date(bidData.bidTime * 1000).toDateString(),
              expireTime: bidData.expireTime * 1 === 0 ? "Never Mind" : new Date(bidData.expireTime * 1000).toDateString(),
              NFT: data.image,
              Name: data.name,    
            })
          } catch(e) {
            console.log(e)
            continue
          }
        }
        
      }
      allTokens.sort(function (a: any, b: any) {
        if (a.name < b.name) { return -1; }
        if (a.name > b.name) { return 1; }
        return 0;
      })
    } catch(err) {
      continue;
    }
  }
  console.log(allTokens)
  return allTokens
}

async function getOfferMade(
  conn: Connection,
  wallet: any,
) {
  console.log("+ get Offer Made")
  const provider = new anchor.Provider(conn, wallet, anchor.Provider.defaultOptions());
  const program = new anchor.Program(idl, buySellProgramId, provider);
  const allData: any = []
  let resp = await conn.getProgramAccounts(buySellProgramId,{
    dataSlice: {length: 0, offset: 0},
    filters: [
      {
        dataSize: BIDDATA_SIZE
      },
      {
        memcmp:
        {
          offset:72,
          bytes: wallet!.publicKey.toBase58()
        }
      },
    ]
  })
  for(let dataAccount of resp){
    try{
      let bidData = await program.account.bidData.fetch(dataAccount.pubkey)
      const nonceBalance = await conn.getBalance(bidData.nonceAccount)
      let status = ""
      if(bidData.status === 0) status = "CANCELED"
      else if (bidData.status ===2) status = "ACCEPTED"
      else if (bidData.status === 3) status = "REJECTED"
      else if(nonceBalance >= bidData.bidAmount) {
        if( new Date().getTime() < bidData.expireTime * 1000)
          status = "ACTIVE"
        else status = "REJECTED"
      }
      else status="INVALID"
      let [pda] = await anchor.web3.PublicKey.findProgramAddress([ Buffer.from("metadata"), TOKEN_METADATA_PROGRAM_ID.toBuffer(), bidData.nftMint.toBuffer(), ], TOKEN_METADATA_PROGRAM_ID);
      let accountInfo: any = await conn.getParsedAccountInfo(pda);
      let metadata : any = new Metadata(wallet.publicKey.toString(), accountInfo.value);
      let { data }: any = await axios.get(metadata.data.data.uri)
      const highest = await getHighestOffer(conn, wallet, bidData.nftMint)
      allData.push({
        bidder : bidData.bidder.toBase58(),
        bidAmount :bidData.bidAmount / (10 ** 9),
        status : status,
        bidData: dataAccount.pubkey,
        nftMint: bidData.nftMint,
        bidTime: new Date(bidData.bidTime * 1000).toDateString(),
        expireTime: bidData.expireTime * 1 === 0 ? "Never Mind" : new Date(bidData.expireTime * 1000).toDateString(),
        NFT: data.image,
        Name: data.name,
        Highest: highest / anchor.web3.LAMPORTS_PER_SOL,
      })
    } catch(e) {
      console.log(e)
      continue
    }
  }
  console.log(allData)
  return allData
}

async function getHighestOffer(
  conn: any,
  wallet: any,
  nftMint: PublicKey,
) {
  console.log("+ get Highest Offer")
  const provider = new anchor.Provider(conn, wallet, anchor.Provider.defaultOptions());
  const program = new anchor.Program(idl, buySellProgramId, provider);
  let resp = await conn.getProgramAccounts(buySellProgramId,{
    dataSlice: {length: 0, offset: 0},
    filters: [
      {
        dataSize: BIDDATA_SIZE
      },
      {
        memcmp:
        {
          offset:8,
          bytes: nftMint.toBase58()
        }
      },
    ]
  })
  let highest = 0
  for(let dataAccount of resp){
    try{
      let bidData = await program.account.bidData.fetch(dataAccount.pubkey)
      const nonceBalance = await conn.getBalance(bidData.nonceAccount)
      if(bidData.status === 1 && nonceBalance >= bidData.bidAmount) {
        if(highest < bidData.bidAmount) highest = bidData.bidAmount
      } 
    } catch(e) {
      console.log(e)
      continue
    }
  }
  return highest
}

const getCandyMachineCreator = async (
  candyMachine: anchor.web3.PublicKey,
): Promise<[anchor.web3.PublicKey, number]> => {
  return await anchor.web3.PublicKey.findProgramAddress(
    [Buffer.from('candy_machine'), candyMachine.toBuffer()],
    CANDY_MACHINE_PROGRAM,
  );
};


async function getCollection(
  conn: any,
  candy_machine_id: any,
){
  console.log("+ get Collection")
  const allTokens: any = []
  const [candyMachineCreator, creatorBump] = await getCandyMachineCreator(
    new PublicKey(candy_machine_id),
  );
  console.log(candyMachineCreator.toBase58())
  const metadataAccounts = await conn.getProgramAccounts(
    TOKEN_METADATA_PROGRAM_ID,
    {
      filters: [
        {
          memcmp: {
            offset:
              1 +
              32 +
              32 +
              4 +
              MAX_NAME_LENGTH +
              4 +
              MAX_URI_LENGTH +
              4 +
              MAX_SYMBOL_LENGTH +
              2 +
              1 +
              4 +
              0 * MAX_CREATOR_LEN,
            bytes: candyMachineCreator.toBase58(),
          },
        },
      ],
    }
  );
  
  for (let index = 0; index < metadataAccounts.length; index++) {
    try{
      const account = metadataAccounts[index];
      const accountInfo = await conn.getParsedAccountInfo(account.pubkey);
      // @ts-ignore
      const metadata =new Metadata(candyMachineCreator.toString(), accountInfo.value);
      let { data }: any = await axios.get(metadata.data.data.uri)
      allTokens.push({...data, mint: metadata.data.mint})
    } catch(e) {
    }
  }
  console.log(allTokens)
  return allTokens
}

export default function Page(){
	const wallets = useWallet()
  const connection = useConnection()

  const [nfts, setNfts] = useState<any>([])
  const [biddingWalletAddress, setBiddingWalletAddress] = useState<any>([])
  const [biddingWalletBalance, setBiddingWalletBalance] = useState<any>(0)
  const [offerReceived, setOfferReceived] = useState<any>([])
  const [offerDatas, setOfferDatas] = useState<any>([])

  const [wDAmount, setWDAmount] = useState(0)
  const [address, setAddress] = useState("0x");
  const [offerAmount, setOfferAmount] = useState(0)
  const [expireTime, setExpireTime] = useState("1D")

  const [monkPayAddress, setMonkPayAddress] = useState<any>(null);
  const [myInfo, setMyinfo] = useState({solAmount: 0, usdtAmount: 0, address: '0x'});

  const [monkPayData, setMonkPayData] = useState({authority:'0x', totalAccount:0, totalUSDT:0, totalSol:0});
  useEffect(() => {
    if(wallets.connected)
      {
        getAccountData();
        getMonkPayData();
      }
  }, [wallets])

  useEffect(()=>{
    getMonkPayAddress();
  },[])

  const getMonkPayAddress = async ()=>{
    let monkpayData = await findMonkpayData( connection.connection, wallets);
    if(monkpayData == null) return
    setMonkPayAddress(monkpayData.address);
  }
  const getAccountData = async ()=>{
    let accountData = await findAccountData(connection.connection, wallets);
    if(accountData == null) return

    console.log({solAmount: accountData.data.solAmount.toNumber(), usdtAmount: accountData.data.usdtAmount.toNumber(), address: accountData.data.owner.toBase58()});

    setMyinfo({solAmount: accountData.data.solAmount.toNumber(), usdtAmount: accountData.data.usdtAmount.toNumber()/1000000, address: accountData.data.owner.toBase58()})
  }

  const getMonkPayData = async () => {
    let monkpayData = await findMonkpayData(connection.connection, wallets);
    if(monkpayData == null) return
    console.log(monkpayData.data);

    let usdtBalance = await getSPLTokenBalance(connection.connection, monkpayData.data.usdtAccount);
    setMonkPayData({authority:monkpayData.data.owner.toBase58(), totalAccount: 0, totalSol:0, totalUSDT: usdtBalance});
  }

	return (
    <div className="container-fluid mt-4">
      <div className="row mb-3">
        <div className="col-md-12">
          <h6>Monkpay Account</h6>
          <div>
            <span>amount: </span>
            <input value={wDAmount} onChange={(e: any) => setWDAmount(e.target.value)}/>
          </div>
          <div>
            <span>address: </span>
            <input value={address} onChange={(e: any) => setAddress(e.target.value)}/>
          </div>
          <button type="button" className="btn btn-warning m-1" onClick={async () =>{
            let monk = await initMonkpay(connection.connection, wallets, wDAmount);
            setMonkPayAddress(monk);
          }}>Init Monkpay</button>
          <button type="button" className="btn btn-warning m-1" onClick={async () =>{
            await initAccount(connection.connection, wallets, monkPayAddress)
            getMonkPayData();
          }}>Init Account</button>
          <button type="button" className="btn btn-warning m-1" onClick={async () =>{
            await depositUSDT(connection.connection, wallets, wDAmount, monkPayAddress);
            getMonkPayData();
            getAccountData();
          }}>Deposit USDT</button>
          <button type="button" className="btn btn-warning m-1" onClick={async () =>{
            await withdrawUSDT(connection.connection, wallets, wDAmount, monkPayAddress);
            getMonkPayData();
            getAccountData();
          }}>Withdraw USDT</button>
          <button type="button" className="btn btn-warning m-1" onClick={async () =>{
             await transferUSDT(connection.connection, wallets, wDAmount, new PublicKey(address) )
            getMonkPayData();
            getAccountData();
          }}>Transfer USDT</button>

          <button type="button" className="btn btn-warning m-1" onClick={async () =>{
            await refundUSDT(connection.connection, wallets, wDAmount, monkPayAddress)
            getMonkPayData();
            getAccountData();
          }}>Refund USDT</button>
        </div>
    
      </div>
      <hr/>

      <div>
        <h6>My Info</h6>
        <p><span>Account Owner:</span> {myInfo.address}</p>
        <p><span>Sol Amount:</span> {myInfo.solAmount}</p>
        <p><span>USDT Amount:</span> {myInfo.usdtAmount}</p>

        <h6>Monkpay Info</h6>
        <p><span>Authority:</span> {monkPayData.authority}</p>
        <p><span>total Accounts:</span> {monkPayData.totalAccount}</p>
        <p><span>Sol totalAmount:</span> {monkPayData.totalSol}</p>
        <p><span>USDT totalAcmount:</span> {monkPayData.totalUSDT}</p>


      </div>
   </div> 
  )
}