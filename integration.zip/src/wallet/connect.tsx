import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';

export default function WalletConnect(): JSX.Element {
  return <WalletMultiButton />;
}
