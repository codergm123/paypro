you need to download node modules for the first.
then run integration code 

1. npm install
2. npm start